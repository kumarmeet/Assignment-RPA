const mongodb = require("mongodb");
const db = require("../database/database");

class User {
  constructor(userData) {
    this.name = userData.name;
    this.email = userData.email;
    this.phone = userData.phone;
    this.country = userData.country;
    this.city = userData.city;
    this.description = userData.description;
    this.image = userData.image;
    this.updateImageData();
    if (userData._id) {
      this.id = userData._id.toString();
    }
  }

  updateImageData() {
    //below fields not stored in database due to handle image path and image url and will use in templates
    this.imagePath = `uploaded-images/${this.image}`;
    this.imageUrl = `/users/images/${this.image}`;
  }

  async save() {
    const user = {
      name: this.name,
      email: this.email,
      phone: this.phone,
      country: this.country,
      city: this.city,
      description: this.description,
      image: this.image,
    };

    if (this.id) {
      const uid = new mongodb.ObjectId(this.id); //it converts string to mongodb object id

      //dont override image data into db
      if (!this.image) {
        delete user.image;
      }

      await db.getDb().collection("users").updateOne(
        { _id: uid },
        {
          $set: user,
        }
      );
    } else {
      return await db.getDb().collection("users").insertOne(user);
    }
  }

  static async fetchAllData() {
    const users = await db.getDb().collection("users").find().toArray();

    //return new User because we need to rebuild imagePath and imageUrl fields
    return users.map((userDoc) => {
      return new User(userDoc);
    });
  }

  static async findUser(userId) {
    const uid = new mongodb.ObjectId(userId); //it converts string to mongodb object id
    const user = await db.getDb().collection("users").findOne({ _id: uid });
    return new User(user);
  }

  static async findByEmailAndPhone(userEmail, userPhone) {
    if (userEmail) {
      return await db.getDb().collection("users").findOne({ email: userEmail });
    }
    return await db.getDb().collection("users").findOne({ phone: userPhone });
  }

  //image update logic
  async replaceImage(newImg) {
    this.image = newImg;
    this.updateImageData();
  }
}

module.exports = User;
