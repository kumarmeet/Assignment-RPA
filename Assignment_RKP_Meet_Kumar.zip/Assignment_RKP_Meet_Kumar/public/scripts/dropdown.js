const countryEl = document.getElementById("country");
const cityEl = document.getElementById("city");

//data
const fetchData = async () => {
  const response = await fetch("/user-details");
  const data = await response.json();
  return data;
};

//logic of dropdown
window.onload = async function () {
  const data = await fetchData();

  const countrySel = document.getElementById("country");
  const citySel = document.getElementById("city");

  for (const country in data) {
    countrySel.options[countrySel.options.length] = new Option(
      country,
      country
    );
  }

  countrySel.addEventListener("change", function () {
    citySel.length = 1;
    for (const y of data[this.value]) {
      citySel.options[citySel.options.length] = new Option(y, y);
    }
  });
};
