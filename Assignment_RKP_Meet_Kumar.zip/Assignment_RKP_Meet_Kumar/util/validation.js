const isEmpty = (name, email, phone, country, city, description) => {
  return name && email && phone && country && city && description;
};

const isEmail = (email) => {
  return email.includes("@");
};

//brazil has 11 max digit and india has 10 max digit
const isPhone = (phone) => {
  return phone.length >= 10 && phone.length <= 11 && phone.match(/^\d{10}$/);
};

module.exports = {
  isEmpty,
  isEmail,
  isPhone,
};
