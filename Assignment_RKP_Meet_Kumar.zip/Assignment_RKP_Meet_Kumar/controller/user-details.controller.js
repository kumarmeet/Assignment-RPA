const User = require("../model/User.model");

const validationSession = require("../util/validation-session");
const validation = require("../util/validation");

const home = (req, res) => {
  const sessionErrorData = validationSession.getSessionErrorData(req, {
    name: "",
    email: "",
    phone: "",
    country: "",
    city: "",
    description: "",
  });
  res.render("user-detail-form", { inputData: sessionErrorData });
};

//for ajax request
const getDropDownData = (req, res) => {
  res.json({
    India: ["Bhopal", "Indore"],
    Brazil: ["São Paulo", "Rio de Janeiro"],
  });
};

const postUserDetailsForm = async (req, res, next) => {
  const user = {
    name: req.body.name,
    email: req.body.email,
    phone: req.body.phone,
    country: req.body.country,
    city: req.body.city,
    description: req.body.description,
  };

  if (
    !validation.isEmpty(
      user.name,
      user.email,
      user.phone,
      user.country,
      user.city,
      user.description
    )
  ) {
    validationSession.flashErrorsToSession(
      req,
      {
        message: "Fields are empty",
        name: user.name,
        email: user.email,
        phone: user.phone,
        country: user.country,
        city: user.city,
        description: user.description,
      },
      () => {
        res.redirect("/");
      }
    );
    return;
  }

  if (!validation.isEmail(user.email)) {
    validationSession.flashErrorsToSession(
      req,
      {
        message: "Email is not valid",
        name: user.name,
        email: user.email,
        phone: user.phone,
        country: user.country,
        city: user.city,
        description: user.description,
      },
      () => {
        res.redirect("/");
      }
    );
    return;
  }

  if (!validation.isPhone(user.phone)) {
    validationSession.flashErrorsToSession(
      req,
      {
        message:
          "Phone number should must be number and between 10 to 11 digits",
        name: user.name,
        email: user.email,
        phone: user.phone,
        country: user.country,
        city: user.city,
        description: user.description,
      },
      () => {
        res.redirect("/");
      }
    );
    return;
  }

  const newUser = new User({
    ...req.body,
    image: req.file.filename,
  });

  //user exist
  try {
    const isUserEmailExists = await User.findByEmailAndPhone(req.body.email);
    const isUserPhoneExists = await User.findByEmailAndPhone(
      null,
      req.body.phone
    );

    if (isUserEmailExists || isUserPhoneExists) {
      validationSession.flashErrorsToSession(
        req,
        {
          message: "User already exists",
          name: user.name,
          email: user.email,
          phone: user.phone,
          country: user.country,
          city: user.city,
          description: user.description,
        },
        () => {
          res.redirect("/");
        }
      );
      return;
    }
  } catch (error) {
    return next(error);
  }

  //save user details
  try {
    await newUser.save(newUser);

    if (newUser) {
      validationSession.flashErrorsToSession(
        req,
        {
          message: "You form submitted successfully",
        },
        () => {
          res.redirect("/");
        }
      );
      return;
    }
  } catch (error) {
    return next(error);
  }

  res.redirect("/");
};

const getAllData = async (req, res, next) => {
  try {
    const allUserData = await User.fetchAllData();
    res.render("all-user-data", { usersData: allUserData });
  } catch (error) {
    return next(error);
  }
};

const getUserUpdate = async (req, res, next) => {
  try {
    const userFound = await User.findUser(req.params.id);
    res.render("update-user-details", { user: userFound });
  } catch (error) {
    return next();
  }
};

const UpdateUser = async (req, res, next) => {
  const user = new User({
    ...req.body,
    _id: req.params.id,
  });

  if (req.file) {
    //if image are set then this if block executes eg: for updating the user details
    user.replaceImage(req.file.filename);
  }

  try {
    await user.save();
  } catch (error) {
    return next(error);
  }

  res.redirect("/all-users");
};

module.exports = {
  home: home,
  getDropDownData: getDropDownData,
  postUserDetailsForm: postUserDetailsForm,
  getAllData: getAllData,
  getUserUpdate: getUserUpdate,
  UpdateUser: UpdateUser,
};
