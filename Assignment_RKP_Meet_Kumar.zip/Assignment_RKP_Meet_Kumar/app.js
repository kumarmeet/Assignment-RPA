const path = require("path");
const express = require("express");
const session = require("express-session");

const db = require("./database/database");
const sessionConfig = require("./config/session");

const userDetailsRoutes = require("./routes/user-details.routes");

const mongodbSessionStore = sessionConfig.createSessionStore(session);

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static("public"));
// (/users/images) this path is comes from userModel file
app.use("/users/images", express.static("uploaded-images")); //it will show user uploaded images
app.use(express.urlencoded({ extended: false }));

app.use(session(sessionConfig.createSessionConfig(mongodbSessionStore)));
app.use(express.json());

app.use(userDetailsRoutes);

//resource not found
app.use((req, res, next) => {
  res.status(404).render("404");
});

// server side error
app.use((error, req, res, next) => {
  res.status(500).render("500");
});

//setting up server
let port = 3000;

if (process.env.PORT) {
  port = process.env.PORT;
}

db.connectToDatabase()
  .then(() => {
    app.listen(port);
  })
  .catch((error) => {
    console.log("Database not connected!");
  });
