const express = require("express");
const router = express.Router();

const imageUploadMiddleware = require("../middleware/imageUploadMiddileware");

const userDetailsController = require("../controller/user-details.controller");

router.get("/", userDetailsController.home);

router.get("/user-details", userDetailsController.getDropDownData);

router.post(
  "/",
  imageUploadMiddleware,
  userDetailsController.postUserDetailsForm
);

router.get("/all-users", userDetailsController.getAllData);

//updating routes
router.get("/user/:id/edit", userDetailsController.getUserUpdate);

router.post(
  "/user/:id/edit",
  imageUploadMiddleware,
  userDetailsController.UpdateUser
);

module.exports = router;
